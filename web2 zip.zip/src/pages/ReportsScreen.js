import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, Search, Filter, CheckCircle2, AlertTriangle, Calendar, ChevronRight } from 'lucide-react';
import BottomNav from '../components/BottomNav';

const ReportsScreen = () => {
  const navigate = useNavigate();
  
  const reports = [
    { name: "Metformin Derivative", formula: "CN(C)C(=N)NC(=N)N", toxicityScore: 15, date: "Feb 13, 2026", status: "Safe" },
    { name: "GLP-1 Analog", formula: "CC(C)CC1NC(=O)C(NC(=O)C2CCCN2)CCC(=O)I", toxicityScore: 42, date: "Feb 12, 2026", status: "Moderate" },
    { name: "SGLT2 Inhibitor", formula: "CC1=CC=C(C=C1)C2=CC(=O)C3=C(O2)C=C(C=C3O", toxicityScore: 68, date: "Feb 11, 2026", status: "Warning" },
    { name: "DPP-4 Inhibitor", formula: "C1CN(CC2=C1C=CC(=C2)F)CC(=O)N3CCN(CC3)C4=NC=CC=C4", toxicityScore: 25, date: "Feb 10, 2026", status: "Safe" },
    { name: "Thiazolidinedione Derivative", formula: "CC1=CC=C(C=C1)CCC2C(=O)NC(=O)S2", toxicityScore: 38, date: "Feb 9, 2026", status: "Moderate" }
  ];

  return (
    <div className="dashboard-container">
      
      {/* Header Block Gradient explicitly distinct */}
      <div style={{ background: 'linear-gradient(180deg, #2563EB 0%, #0D9488 100%)', padding: 24, paddingBottom: 40, borderBottomLeftRadius: 32, borderBottomRightRadius: 32 }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 24 }}>
          <div style={{ backgroundColor: 'rgba(255,255,255,0.2)', padding: 12, borderRadius: 12 }}>
            <FileText size={24} color="white" />
          </div>
          <div style={{ marginLeft: 16 }}>
            <div style={{ color: 'white', fontSize: 24, fontWeight: 'bold' }}>Saved Reports</div>
            <div style={{ color: 'rgba(255,255,255,0.8)', fontSize: 14 }}>{reports.length} analysis reports</div>
          </div>
        </div>

        {/* Search Bar */}
        <div style={{ display: 'flex', alignItems: 'center', backgroundColor: 'white', borderRadius: 12, height: 50, padding: '0 16px' }}>
          <Search size={20} color="gray" style={{ marginRight: 12 }} />
          <input 
            type="text" 
            placeholder="Search reports..." 
            style={{ border: 'none', outline: 'none', flex: 1, fontSize: 14 }}
          />
          <Filter size={20} color="#3B82F6" style={{ cursor: 'pointer' }} />
        </div>
      </div>

      <div className="dashboard-content" style={{ padding: '24px 16px', marginTop: -20 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {reports.map((report, idx) => {
            const isSafe = report.status === 'Safe';
            const isWarning = report.status === 'Warning';
            const statusColor = isSafe ? '#22C55E' : isWarning ? '#EF4444' : '#F59E0B';
            
            return (
              <div key={idx} className="analysis-item" style={{ padding: 20 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <div style={{ fontSize: 18, fontWeight: 'bold', color: '#1E293B' }}>{report.name}</div>
                    <div style={{ fontSize: 12, color: 'gray', marginTop: 4 }}>{report.formula.substring(0, 30)}{report.formula.length > 30 ? '...' : ''}</div>
                  </div>
                  
                  <div style={{ backgroundColor: `${statusColor}1A`, padding: '4px 8px', borderRadius: 12, display: 'flex', alignItems: 'center', gap: 4 }}>
                    {isSafe ? <CheckCircle2 size={14} color={statusColor} /> : <AlertTriangle size={14} color={statusColor} />}
                    <span style={{ fontSize: 12, fontWeight: 'bold', color: statusColor }}>{report.status}</span>
                  </div>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 20 }}>
                  <div style={{ fontSize: 14, color: 'gray' }}>Toxicity Score</div>
                  <div style={{ fontSize: 14, fontWeight: 'bold', color: '#1E293B' }}>{report.toxicityScore}%</div>
                </div>

                <div className="progress-bar-bg" style={{ marginTop: 8, height: 8 }}>
                  <div className="progress-fill" style={{ backgroundColor: statusColor, width: `${report.toxicityScore}%` }}></div>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 20 }}>
                  <div style={{ display: 'flex', alignItems: 'center', color: 'gray', fontSize: 13 }}>
                    <Calendar size={16} style={{ marginRight: 8 }} />
                    {report.date}
                  </div>
                  <div style={{ color: '#3B82F6', fontSize: 14, fontWeight: 600, display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                    View Details
                    <ChevronRight size={16} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <BottomNav />
    </div>
  );
};

export default ReportsScreen;
